import { NgbModalOptions } from "@ng-bootstrap/ng-bootstrap";


export const environment = {
  production: true
};


export const config: any= {
apiUrl : "https://localhost:44327/api/",
modalConfig: <NgbModalOptions>{
  size: "lg",
  backdrop: "static",
  keyboard: false,
},
};

export const endpoint: any = {

  // ej   companyUrl: config.apiUrl + "company",

  clientUrl : config.apiUrl + "CLIENT",
  autoUrl: config.apiUrl + "AUTOMOVIL",
  mecanicoUrl: config.apiUrl + "MECANICO",
  solicituddUrl: config.apiUrl+ "SOLICITUD",
  
  reciboUrl : config.apiUrl + "RECIBO",
  listreciboUrl: config.apiUrl + "ListRecibo",
  listsolicitudUrl: config.apiUrl + "ListSolicitud"

};
