import { NgbActiveModal } from "@ng-bootstrap/ng-bootstrap";
import { AutoService } from '../core/services/auto.service';
import { Auto} from '../core/models/auto.model';
import { Client } from '../core/models/client.model';
import { AlertService } from '../core/services/alert.service';
import { ClientService } from '../core/services/client.service';
import { Component, Output, EventEmitter, Input, OnInit } from "@angular/core";
import Swal from 'sweetalert2'


@Component({
  selector: 'app-client-add',
  templateUrl: './client-add.component.html',
  styleUrls: ['./client-add.component.css']
})
export class ClientAddComponent implements OnInit {
  client: Client = new Client();
  @Input()
  auto : Auto[];
  id: any;
  title = "";

  @Output() notifyParent: EventEmitter<any> = new EventEmitter();

  constructor(
    public activeModal: NgbActiveModal,
    private autoservice : AutoService,
    private alertService: AlertService,
    private clientservice : ClientService
  ) { }

  ngOnInit(): void {
    this.onLoad();
    this.title = this.id
    ? "Editar Información de la empresa"
    : "Agregar nueva empresa";
  if (this.id) {
      this.clientservice
        .getById(this.id)
        .subscribe((res) => (this.client = res));
    }
  }

  save() {
    if(this.validate()){
     return Swal.fire({
        icon: 'info',
        title: 'Por favor completar todos los campos :)',

      })

    }
    if (this.id) this.edit();
    else this.add();
  }


  add() {

    Swal.fire({
      icon: 'info',
      title: 'Espere por favor',
    })
    Swal.showLoading();
    this.clientservice.postClient(this.client).subscribe(
      (response) => {
        Swal.close();

        Swal.fire({
          position: 'top-end',
          icon: 'success',
          title: 'Cliente creado exitosamente',
          showConfirmButton: false,
          timer: 1500
        })
        this.activeModal.close();

      },
      (error) => {

        Swal.fire({
          icon: 'error',
          title: 'Oops...',
        })

      }
    );
  }

  validate(){

    return (!this.client.nombre || !this.client.apellido || !this.client.direccion || !this.client.cedula || !this.client.iD_AUTOMOVIL)
  }

  edit() {
    this.alertService.question(() => {
      this.clientservice.put(this.client).subscribe(
        (response) => {
          this.alertService.success(
            "Datos del cliente modificados con exito."
          );
          this.notifyParent.emit();
          this.activeModal.close();
        },
        (error) => {
          this.alertService.error(error.error);
        }
      );
    }, "Seguro que desea modificar la información del cliente.");
  }




  onLoad() {
    this.autoservice.getAll().subscribe((auto) => (this.auto = auto));

  }

}
