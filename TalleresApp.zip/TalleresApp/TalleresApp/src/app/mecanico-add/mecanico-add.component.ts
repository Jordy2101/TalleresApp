import { Component, Output, EventEmitter, Input, OnInit } from "@angular/core";
import { Mecanico } from '../core/models/mecanico.model';
import { MecanicoService } from '../core/services/mecanico.service';
import { NgbActiveModal } from "@ng-bootstrap/ng-bootstrap";
import Swal from 'sweetalert2'

@Component({
  selector: 'app-mecanico-add',
  templateUrl: './mecanico-add.component.html',
  styleUrls: ['./mecanico-add.component.css']
})
export class MecanicoAddComponent implements OnInit {

mecanico : Mecanico = new Mecanico();

@Output() notifyParent: EventEmitter<any> = new EventEmitter();


  constructor(

    public activeModal : NgbActiveModal,
    private mecanicoservices: MecanicoService
  ) { }

  ngOnInit(): void {
  }



  save() {
    if(this.validate()){
     return Swal.fire({
        icon: 'info',
        title: 'Por favor completar todos los campos :)',

      })

    }

    this.add();

    // if (this.id) this.edit();
    // else this.add();
  }




  add() {

    Swal.fire({
      icon: 'info',
      title: 'Espere por favor',
    })

    this.mecanicoservices.postMecanico(this.mecanico).subscribe(
      (response) => {
        Swal.close();

        Swal.fire({
          position: 'top-end',
          icon: 'success',
          title: 'Cliente creado exitosamente',
          showConfirmButton: false,
          timer: 1500
        })
        this.activeModal.close();

      },
      (error) => {

        Swal.fire({
          icon: 'error',
          title: 'Oops...',
        })

      }
    );
  }


  validate(){

    return ( !this.mecanico.nombre || !this.mecanico.apellido || !this.mecanico.direccion || !this.mecanico.tipo_Mecanico || !this.mecanico.especialidad);
  }


}
