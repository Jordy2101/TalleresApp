import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MecanicoAddComponent } from './mecanico-add.component';

describe('MecanicoAddComponent', () => {
  let component: MecanicoAddComponent;
  let fixture: ComponentFixture<MecanicoAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MecanicoAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MecanicoAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
