import { Component, OnInit, Input } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AlertService } from '../core/services/alert.service';
import { MecanicoService } from '../core/services/mecanico.service';
import { Mecanico } from '../core/models/mecanico.model';
import { FilterService} from '../core/services/filter.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { config } from '../../environments/environment.prod';
import Swal from 'sweetalert2'
import { MecanicoAddComponent } from '../mecanico-add/mecanico-add.component';


@Component({
  selector: 'app-mecanico',
  templateUrl: './mecanico.component.html',
  styleUrls: ['./mecanico.component.css']
})
export class MecanicoComponent implements OnInit {

 @Input()
mecanicos : Mecanico[];
page: number = 1;
filter: any = {};
dataPage: any = {};


  constructor(
    private modalService: NgbModal,
    private alert : AlertService,
    private apiService: MecanicoService,
    private loading:NgxSpinnerService,
    private filterService: FilterService
      ) { }

  ngOnInit(): void {
   this.getAll(false);
  }

  //confirmDelete(Id) {
  //  this.alert.question(() => {
   //   this.delete(Id);
   // }, "Esta seguro que desea eliminar la empresa?");
 // }
 confirmDelete(id){
  const swalWithBootstrapButtons = Swal.mixin({
    customClass: {
      confirmButton: 'btn btn-success',
      cancelButton: 'btn btn-danger'
    },
    buttonsStyling: false
  })

  swalWithBootstrapButtons.fire({
    title: 'Seguro de borrar este registro?',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Si, Borrar!',
    cancelButtonText: 'No, cancelar!',
    reverseButtons: true
  }).then((result) => {
    if (result.value) {
      this.delete(id);
      swalWithBootstrapButtons.fire(
        'Borrado!',
        'Se borro el registro'
      )
    } else if (
      /* Read more about handling dismissals below */
      result.dismiss === Swal.DismissReason.cancel
    ) {
      swalWithBootstrapButtons.fire(
        'Cancelado',
        'Proceso cancelado :)'
              )
    }
  })
}

  delete(Id) {
    this.apiService
      .delete(Id)
      .subscribe((res) =>{
        this.getAll(false)
        //this.alert.success("Empresa eliminada con exito")});
      });
  }

  getAll(resetPage: boolean) {
    if (!this.filter.Nombre) this.filter.Nombre = "";
    if (!this.filter.Id) this.filter.Id = 0;
    if (!this.filter.Tipo_Mecanico) this.filter.Tipo_Mecanico = "";
    if (!this.filter.Especialidad) this.filter.Especialidad = "";
    if (resetPage) this.page = 1;
    this.apiService.getPaged(this.filter, this.page).subscribe(
      (response) => {
        this.mecanicos = response.data;
        this.dataPage = response;
        this.loading.hide();
      },
      (error) => {
        this.alert.error(error.error);
        this.loading.hide();
      }
    );

  }

  changePage(next: boolean) {
    this.page = next ? (this.page += 1) : (this.page -= 1);
    if (this.page < 0) this.page = 0;
    this.getAll(false);
  }


 /* editOrAddCompany(Id: number) {

    var modal = this.modalService.open(ClientAddComponent, config.modalConfig);
    modal.componentInstance.id = Id;
    modal.componentInstance.notifyParent.subscribe((result) => {
      if(Id!= null){
      this.getAll(true);
      }
      else {
        this.getAll(false);
      }



    });*/

    editOrAddMecanico(id: number) {

      var modal = this.modalService.open(MecanicoAddComponent, config.modalConfig);
      modal.componentInstance.id = id;
      modal.componentInstance.notifyParent.subscribe((result) => {
        if(id!= null){
        this.getAll(true);
        }
        else {
          this.getAll(false);
        }
      });
    }




  }


