import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';
import { Solicitudd } from '../core/models/solicitudd.model';
import { Client} from '../core/models/client.model';
import { Mecanico } from '../core/models/mecanico.model';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ClientService } from '../core/services/client.service';
import { MecanicoService } from '../core/services/mecanico.service';
import { SolicituddService } from '../core/services/solicitudd.service';
import Swal from 'sweetalert2';



@Component({
  selector: 'app-solicitud-add',
  templateUrl: './solicitud-add.component.html',
  styleUrls: ['./solicitud-add.component.css']
})
export class SolicitudAddComponent implements OnInit {

solicitudd : Solicitudd = new Solicitudd();
@Input()
client : Client[];
mecanico: Mecanico[];
id: any;

@Output() notifyParent: EventEmitter<any> = new EventEmitter();

  constructor(
  public activemodal: NgbActiveModal,
  private clientservice: ClientService,
  private mecanicoservice: MecanicoService,
  private solicituddservice: SolicituddService
  ) { }

  ngOnInit(): void {
    this.onLoad();

    if (this.id) {
      this.solicituddservice
        .getById(this.id)
        .subscribe((res) => (this.solicitudd = res));
    }
  }

save(){
  if(this.validate()){
    return Swal.fire({
       icon: 'info',
       title: 'Por favor completar todos los campos :)',

     })

   }

   if (this.id) this.edit();
   else this.add();
}


  add(){
    Swal.fire({
      icon: 'info',
      title: 'Espere por favor',
    })
    Swal.showLoading();
    this.solicituddservice.postSolicitud(this.solicitudd).subscribe(
      (res) => {

Swal.close();

Swal.fire({
  position: 'top-end',
  icon: 'success',
  title: 'Solicitud creada exitosamente',
  showConfirmButton: false,
  timer: 1500
})
this.activemodal.close();

},
(err) => {

  Swal.fire({
    icon: 'error',
    title: 'Oops...',
     text: err.error

  })
}
);

  }

  validate (){
    return (!this.solicitudd.id_cliente || !this.solicitudd.id_mecanico || !this.solicitudd.descripcion);
  }

edit(){

}


onLoad(){
  this.clientservice.getAll().subscribe((client) => (this.client = client));
  this.mecanicoservice.getAll().subscribe((mecanico)=> (this.mecanico = mecanico));
}

}
