import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SolicitudAddComponent } from './solicitud-add.component';

describe('SolicitudAddComponent', () => {
  let component: SolicitudAddComponent;
  let fixture: ComponentFixture<SolicitudAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SolicitudAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SolicitudAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
