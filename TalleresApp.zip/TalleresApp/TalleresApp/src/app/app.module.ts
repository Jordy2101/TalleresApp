import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ToastrModule } from 'ngx-toastr';

import { AppRoutingModule } from './app.routing';
import { ComponentsModule } from './components/components.module';

import { AppComponent } from './app.component';

import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';
import { AlertService } from './core/services/alert.service';
import { ClientService } from './core/services/client.service';
import { FilterService } from './core/services/filter.service';
import { ClientAddComponent } from './client-add/client-add.component';
import { AutoService } from './core/services/auto.service';
import { MecanicoService } from './core/services/mecanico.service';
import { MecanicoComponent } from './mecanico/mecanico.component';
import { ListReciboService } from './core/services/listrecibo.service';
import { ListSolicitudService } from './core/services/listsolicitud.service';

import { SolicitudService } from './core/services/solicitud.service';
import { SolicitudComponent } from './solicitud/solicitud.component';
import { ReciboComponent } from './recibo/recibo.component';

import { SolicitudAddComponent } from './solicitud-add/solicitud-add.component';
import { ReciboAddComponent } from './recibo-add/recibo-add.component';
import { MecanicoAddComponent } from './mecanico-add/mecanico-add.component';
import { LoginComponent } from './login/login.component';
import { AuthService } from './core/services/auth.service';



@NgModule({
  imports: [
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    ComponentsModule,
    RouterModule,
    AppRoutingModule,
    NgbModule,
    ToastrModule.forRoot()
  ],
  declarations: [
    AppComponent,
    AdminLayoutComponent,
    ClientAddComponent,
    SolicitudAddComponent,
    ReciboAddComponent,
    MecanicoAddComponent








  ],
  providers: [AlertService, ClientService, MecanicoService, FilterService, AutoService,
    ListReciboService, ListSolicitudService, SolicitudService, AuthService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
