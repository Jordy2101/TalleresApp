import { Component, OnInit, Input } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AlertService } from '../core/services/alert.service';
import { ClientService } from '../core/services/client.service';
import { Client } from '../core/models/client.model';
import { FilterService} from '../core/services/filter.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ClientAddComponent } from '../client-add/client-add.component';
import { config } from '../../environments/environment.prod';
import Swal from 'sweetalert2'
@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.css']
})
export class ClientComponent implements OnInit {

 @Input()
clients : Client[];
page: number = 1;
filter: any = {};
dataPage: any = {};


  constructor(
    private modalService: NgbModal,
    private alert : AlertService,
    private apiService: ClientService,
    private loading:NgxSpinnerService,
    private filterService: FilterService
      ) { }

  ngOnInit(): void {
   this.getAll(false);
  }


confirmDelete(id){
  const swalWithBootstrapButtons = Swal.mixin({
    customClass: {
      confirmButton: 'btn btn-success',
      cancelButton: 'btn btn-danger'
    },
    buttonsStyling: false
  })

  swalWithBootstrapButtons.fire({
    title: 'Seguro de borrar este registro?',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Si, Borrar!',
    cancelButtonText: 'No, cancelar!',
    reverseButtons: true
  }).then((result) => {
    if (result.value) {
      this.delete(id);
      swalWithBootstrapButtons.fire(
        'Borrado!',
        'Se borro el registro'
      )
    } else if (
      /* Read more about handling dismissals below */
      result.dismiss === Swal.DismissReason.cancel
    ) {
      swalWithBootstrapButtons.fire(
        'Cancelado',
        'Proceso cancelado :)'
              )
    }
  })
}
  delete(Id) {
    this.apiService
      .delete(Id)
      .subscribe((res) =>{
        this.getAll(false)
        // this.alert.success("Empresa eliminada con exito")
      });
  }

  getAll(resetPage: boolean) {
    if (!this.filter.Nombre) this.filter.Nombre = "";
    if (!this.filter.Apellido) this.filter.Apellido = "";
    if (!this.filter.cedula) this.filter.cedula = "";
    this.loading.show();
    if (resetPage) this.page = 1;
    this.apiService.getPaged(this.filter, this.page).subscribe(
      (response) => {
        this.clients = response.data;
        this.dataPage = response;
        this.loading.hide();
      },
      (error) => {
        this.alert.error(error.error);
        this.loading.hide();
      }
    );
  }
  changePage(next: boolean) {
    this.page = next ? (this.page += 1) : (this.page -= 1);
    if (this.page < 0) this.page = 0;
    this.getAll(false);
  }
  editOrAddCompany(id: number) {

    var modal = this.modalService.open(ClientAddComponent, config.modalConfig);
    modal.componentInstance.id = id;
    modal.componentInstance.notifyParent.subscribe((result) => {
      if(id!= null){
      this.getAll(true);
      }
      else {
        this.getAll(false);
      }
    });
  }

}
