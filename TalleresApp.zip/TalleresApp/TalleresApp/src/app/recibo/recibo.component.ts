import { Component, OnInit, Input } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AlertService } from '../core/services/alert.service';
import { ListRecibo } from '../core/models/listrecibo.model';
import { FilterService} from '../core/services/filter.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { config } from '../../environments/environment.prod';
import { ListReciboService } from '../core/services/listrecibo.service';
import { ClientAddComponent } from '../client-add/client-add.component';

import Swal from 'sweetalert2';
import { ReciboAddComponent } from '../recibo-add/recibo-add.component';

@Component({
  selector: 'app-recibo',
  templateUrl: './recibo.component.html',
  styleUrls: ['./recibo.component.css']
})
export class ReciboComponent implements OnInit {

  @Input()
  recibos: ListRecibo[];
  page: number = 1;
  filter: any = {};
  dataPage: any = {};


  constructor(
    private modalService: NgbModal,
    private alert: AlertService,
   private apiService: ListReciboService,
    private loading: NgxSpinnerService,
    private filterService: FilterService,

  ) { }

  ngOnInit(): void {
    this.getAll(false);
  }


  getAll(resetPage: boolean) {
    if (!this.filter.Nombre_Completo_Cliente) this.filter.Nombre_Completo_Cliente = "";
    if (!this.filter.Id) this.filter.Id = 0;
    if (!this.filter.Cedula) this.filter.Cedula = "";
    if (!this.filter.CreateDate) this.filter.CreateDate = "";
    if (!this.filter.endDate) this.filter.endDate = "";
    if (resetPage) this.page = 1;
    this.apiService.getPaged(this.filter, this.page).subscribe(
      (response) => {
        this.recibos = response.data;
        this.dataPage = response;
        this.loading.hide();

      },
      (error) => {
        this.alert.error(error.error);
        this.loading.hide();
      }
    );

  }

  changePage(next: boolean) {
    this.page = next ? (this.page += 1) : (this.page -= 1);
    if (this.page < 0) this.page = 0;
    this.getAll(false);
  }


  editOrAdd(id: number) {

    var modal = this.modalService.open(ReciboAddComponent, config.modalConfig);
    this.getAll(true);

    // modal.componentInstance.id = id;
    // modal.componentInstance.subscribe((result) => {
    //   if(id!= null){
    //   this.getAll(true);
    //   }
    //   else {
    //     this.getAll(false);
    //   }
    // });
  }


}


