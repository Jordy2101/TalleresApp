import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';
import { Recibo } from '../core/models/recibo.model';
import { Solicitudd } from '../core/models/solicitudd.model';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { SolicituddService } from '../core/services/solicitudd.service';
import { ReciboService } from '../core/services/recibo.service';
import Swal from 'sweetalert2';
import { Client } from '../core/models/client.model';
import { ClientService } from '../core/services/client.service';
import { subscribeOn } from 'rxjs/operators';
import { ListSolicitud } from '../core/models/listsolicitud.model';
import { Solicitud } from '../core/models/solicitud.model';
import { SolicitudService } from '../core/services/solicitud.service';

@Component({
  selector: 'app-recibo-add',
  templateUrl: './recibo-add.component.html',
  styleUrls: ['./recibo-add.component.css']
})
export class ReciboAddComponent implements OnInit {

recibo : Recibo = new Recibo();

@Input()
solicituds : Solicitudd[];
solicitud: Solicitud[];
client : Client[];
vsoliciutd: ListSolicitud[];
id: any;

@Output() notifyParent: EventEmitter<any> = new EventEmitter();


  constructor(
    public activemodal : NgbActiveModal,
    private solicituddservices: SolicituddService,
    private solicitudservices: SolicitudService,
    private reciboservices: ReciboService,
    private clientservices: ClientService
  ) { }

  ngOnInit(): void {

    this.onLoad();
  }


  save(){
    if(this.validate()){
      return Swal.fire({
         icon: 'info',
         title: 'Por favor completar todos los campos :)',

       })

     }

     if (this.id) this.edit();
     else this.add();
  }


add(){
  Swal.fire({
    icon: 'info',
    title: 'Espere por favor',
  })
  Swal.showLoading();
  this.reciboservices.postRecibo(this.recibo).subscribe(
    (res) => {

Swal.close();

Swal.fire({
position: 'top-end',
icon: 'success',
title: 'Solicitud creada exitosamente',
showConfirmButton: false,
timer: 1500
})
this.activemodal.close();

},
(err) => {

Swal.fire({
  icon: 'error',
  title: 'Oops...',
   text: err.error

})
}
);

}


edit(){

}


validate(){
  return (!this.recibo.id_solicitud || !this.recibo.comentario);
}



  onLoad(){

    this.solicitudservices.getAll().subscribe((solicitud) => { console.log(solicitud);(this.solicitud = solicitud)});
    this.clientservices.getAll().subscribe((c) => { console.log(c); (this.client = c)});
  }
}
