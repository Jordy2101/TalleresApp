import { Injectable} from '@angular/core';
import { BaseService} from './base.service';
import { HttpClient} from '@angular/common/http';
import { config,endpoint} from '../../../environments/environment.prod';
import { Filter } from '../models/filter.model';
import { Solicitud } from '../models/solicitud.model';

@Injectable()

export class SolicitudService extends BaseService<Solicitud, number>{

constructor(_httpClient : HttpClient){
  super(_httpClient, endpoint.solicituddUrl);
}

}
