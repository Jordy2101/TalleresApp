import { Injectable} from '@angular/core';
import { BaseService} from './base.service';
import { HttpClient} from '@angular/common/http';
import { config,endpoint} from '../../../environments/environment.prod';
import { ListRecibo } from '../models/listrecibo.model';

@Injectable()

export class ListReciboService extends BaseService<ListRecibo, number>{

constructor(_httpClient : HttpClient){
  super(_httpClient, endpoint.listreciboUrl);
}

getPaged(filter:any,page:number){
 // return this._httpClient.get<any>(endpoint.mecanicoUrl+`/getPaged?PageNumber=${page}&pageSize=10&Nombre=${filter.nombre}&Id_mecanico=${filter.Id_mecanico}&Tipo_Mecanico=${filter.tipo_Mecanico}&Especialidad=${filter.especialidad}`);

  return this._httpClient.get<any>(endpoint.listreciboUrl + `?PageNumber=${page}&PageSize=10&Nombre_Completo_Cliente=${filter.Nombre_Completo_Cliente}&id=${filter.Id}&Cedula=${filter.Cedula}&FirstDate=${filter.CreateDate}&EndDate=${filter.endDate}`);
 
}
 

}
