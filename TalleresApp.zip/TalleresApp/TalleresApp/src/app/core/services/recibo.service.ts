import { Injectable } from '@angular/core';
import { BaseService} from './base.service';
import { HttpClient} from '@angular/common/http';
import { config,endpoint} from '../../../environments/environment.prod';
import { Recibo} from '../models/recibo.model';


@Injectable({
  providedIn: 'root'
})
export class ReciboService extends BaseService<Recibo, number>{

  constructor( _httpClient : HttpClient) {
    super(_httpClient, endpoint.reciboUrl);
   }


   postRecibo(item : any){
    return this._httpClient.get<any>(endpoint.reciboUrl + `/PostRecibo/${item.comentario}/${item.id_solicitud}`);
   }
}
