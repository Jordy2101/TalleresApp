import { Injectable} from '@angular/core';
import { BaseService} from './base.service';
import { HttpClient} from '@angular/common/http';
import { config,endpoint} from '../../../environments/environment.prod';
import { ListSolicitud } from '../models/listsolicitud.model';
import { Filter } from '../models/filter.model';

@Injectable()

export class ListSolicitudService extends BaseService<ListSolicitud, number>{

constructor(_httpClient : HttpClient){
  super(_httpClient, endpoint.listsolicitudUrl);
}

getPaged(filter:any,page:number){
 // return this._httpClient.get<any>(endpoint.mecanicoUrl+`/getPaged?PageNumber=${page}&pageSize=10&Nombre=${filter.nombre}&Id_mecanico=${filter.Id_mecanico}&Tipo_Mecanico=${filter.tipo_Mecanico}&Especialidad=${filter.especialidad}`);

  return this._httpClient.get<any>(endpoint.listsolicitudUrl + `?PageNumber=${page}&PageSize=10&Nombre_Completo_Cliente=${filter.Nombre_Completo_Cliente}&id=${filter.Id}&Cedula=${filter.Cedula}&FirstDate=${filter.CreateDate}&EndDate=${filter.endDate}`);
 
}
}
