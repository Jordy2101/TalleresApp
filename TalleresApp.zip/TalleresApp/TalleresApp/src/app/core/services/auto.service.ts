import { Injectable} from '@angular/core';
import { BaseService} from './base.service';
import { HttpClient} from '@angular/common/http';
import { config,endpoint} from '../../../environments/environment.prod';
import { Auto } from '../models/auto.model';

@Injectable()
export class AutoService extends BaseService<Auto, number> {

  constructor(_httpClient : HttpClient) {
    super(_httpClient, endpoint.autoUrl);
  }
}
