import { Injectable } from '@angular/core';
import { BaseService} from './base.service';
import { HttpClient} from '@angular/common/http';
import { config,endpoint} from '../../../environments/environment.prod';
import { Solicitudd}from '../models/solicitudd.model';
@Injectable({
  providedIn: 'root'
})
export class SolicituddService extends BaseService<Solicitudd, number>{

  constructor( _httpClient : HttpClient) {

    super(_httpClient, endpoint.solicitudUrl);
   }

postSolicitud(item: any){

  return this._httpClient.get<any>(endpoint.solicituddUrl + `/PostSolicitud/${item.id_mecanico}/${item.id_cliente}/${item.descripcion}`);
}

}
