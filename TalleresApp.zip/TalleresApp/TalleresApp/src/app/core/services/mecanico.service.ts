import { Injectable} from '@angular/core';
import { BaseService} from './base.service';
import { HttpClient} from '@angular/common/http';
import { config,endpoint} from '../../../environments/environment.prod';
import { Mecanico } from '../models/mecanico.model';

@Injectable()

export class MecanicoService extends BaseService<Mecanico, number>{

constructor(_httpClient : HttpClient){
  super(_httpClient, endpoint.mecanicoUrl);
}

getPaged(filter:any,page:number){
 // return this._httpClient.get<any>(endpoint.mecanicoUrl+`/getPaged?PageNumber=${page}&pageSize=10&Nombre=${filter.nombre}&Id_mecanico=${filter.Id_mecanico}&Tipo_Mecanico=${filter.tipo_Mecanico}&Especialidad=${filter.especialidad}`);

  return this._httpClient.get<any>(endpoint.mecanicoUrl + `/getPaged?PageNumber=${page}&PageSize=10&Nombre=${filter.Nombre}&Id=${filter.Id}&Tipo_Mecanico=${filter.Tipo_Mecanico}&Especialidad=${filter.Especialidad}`);

  }
  

  postMecanico(item: any){
    return this._httpClient.get<any>(endpoint.mecanicoUrl+ `/PostMecanico/${item.nombre}/${item.apellido}/${item.direccion}/${item.tipo_Mecanico}/${item.especialidad}`);
  }


}
