import { Injectable} from '@angular/core';
import { BaseService} from './base.service';
import { HttpClient} from '@angular/common/http';
import { config,endpoint} from '../../../environments/environment.prod';
import { Client } from '../models/client.model';

@Injectable()

export class ClientService extends BaseService<Client, number>{

constructor(_httpClient : HttpClient){
  super(_httpClient, endpoint.clientUrl);
}

getPaged(filter:any,page:number){
  return this._httpClient.get<any>(endpoint.clientUrl+`/getPaged?PageNumber=${page}&pageSize=10&Nombre=${filter.Nombre}&Apellido=${filter.Apellido}&cedula=${filter.cedula}`);
}

postClient(item: any){
  return this._httpClient.get<any>(endpoint.clientUrl+ `/PostClient/${item.nombre}/${item.apellido}/${item.direccion}/${item.cedula}/${item.iD_AUTOMOVIL}`);
}

}
