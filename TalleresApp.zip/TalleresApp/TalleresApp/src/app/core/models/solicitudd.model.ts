import {BaseModel} from './base.model';
import { from } from 'rxjs';
export class Solicitudd extends BaseModel{

  id: number
  id_mecanico: number
  id_cliente : number
  descripcion : string

}
