import {BaseModel} from './base.model';
import { from } from 'rxjs';
export class Client extends BaseModel{

  id:number
  nombre: string
  apellido: string
  cedula : string
  direccion : string
  iD_AUTOMOVIL : number
  modelo : string
}
