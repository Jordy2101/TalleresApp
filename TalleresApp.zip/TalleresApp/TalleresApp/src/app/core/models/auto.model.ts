import {BaseModel} from './base.model';
import { from } from 'rxjs';

export class Auto extends BaseModel{

id: number
color : string
marca : string
transmision : string
lugar_Fabricacion : string
tipo  : string
modelo : string
}
