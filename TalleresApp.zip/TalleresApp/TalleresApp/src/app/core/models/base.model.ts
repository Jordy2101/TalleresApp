export class BaseModel {
Id: number
CreateDate: Date
ModifiedDate : Date
status: string
}
