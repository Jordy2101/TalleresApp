import {BaseModel} from './base.model';
import { from } from 'rxjs';
export class Solicitud extends BaseModel{

id: number
  descripcion: string
    nombre_Cliente: string
    nombre_Mecanico: string
    especialidad: string
    cedula: string
    iD_MECANICO: number
    iD_CLIENTE: number


}
