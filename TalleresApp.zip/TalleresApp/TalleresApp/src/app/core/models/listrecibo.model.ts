import {BaseModel} from './base.model';
import { from } from 'rxjs';
export class ListRecibo extends BaseModel{

id : number
  iD_SOLICITUD: number
  iD_CLIENTE: number
  nombre_Completo_Cliente: string
  cedula : string
  iD_MECANICO:number
  nombre_Completo_Mecanico: string
  especialidad: string
  comentario: string
  date: Date

}
