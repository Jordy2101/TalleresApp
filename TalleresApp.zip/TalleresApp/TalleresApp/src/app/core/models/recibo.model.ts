import {BaseModel} from './base.model';
import { from } from 'rxjs';
export class Recibo extends BaseModel{

  id_solicitud: number
  comentario : string

}
