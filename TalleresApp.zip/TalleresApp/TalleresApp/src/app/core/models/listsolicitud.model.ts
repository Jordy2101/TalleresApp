import {BaseModel} from './base.model';
import { from } from 'rxjs';
export class ListSolicitud extends BaseModel{

  id: number
  iD_CLIENTE: number
  nombre_Completo_Cliente: string
  cedula : string
  iD_MECANICO:number
  nombre_Completo_Mecanico: string
  tipo_Mecanico: string
  especialidad: string
  countCar: number
  descripcion: string
  date: Date

}
