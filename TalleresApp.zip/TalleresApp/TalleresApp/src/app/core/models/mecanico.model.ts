import {BaseModel} from './base.model';
import { from } from 'rxjs';
export class Mecanico extends BaseModel{

  id: number
  nombre: string
  apellido: string
  direccion : string
  tipo_Mecanico: string
  especialidad: string
  countCar: number

}
