import { Component, OnInit, Input } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AlertService } from '../core/services/alert.service';
import { ListSolicitudService } from '../core/services/listsolicitud.service';
import { ListSolicitud } from '../core/models/listsolicitud.model';
import { FilterService} from '../core/services/filter.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { config } from '../../environments/environment.prod';
import { SolicitudAddComponent } from '../solicitud-add/solicitud-add.component';

@Component({
  selector: 'app-solicitud',
  templateUrl: './solicitud.component.html',
  styleUrls: ['./solicitud.component.css']
})
export class SolicitudComponent implements OnInit {

  @Input()
  solicitudes: ListSolicitud[];
  page: number = 1;
  filter: any = {};
  dataPage: any = {};


  constructor(
    private modalService: NgbModal,
    private alert: AlertService,
    private apiService: ListSolicitudService,
    private loading: NgxSpinnerService,
    private filterService: FilterService
  ) { }

  ngOnInit(): void {
    this.getAll(false);
  }

  confirmDelete(Id) {
    this.alert.question(() => {
      this.delete(Id);
    }, "Esta seguro que desea eliminar la empresa?");
  }
  delete(Id) {
    this.apiService
      .delete(Id)
      .subscribe((res) => {
        this.getAll(false)
        this.alert.success("Empresa eliminada con exito")
      });
  }

  getAll(resetPage: boolean) {
    if (!this.filter.Nombre_Completo_Cliente) this.filter.Nombre_Completo_Cliente = "";
    if (!this.filter.Id) this.filter.Id = 0;
    if (!this.filter.Cedula) this.filter.Cedula = "";
    if (!this.filter.CreateDate) this.filter.CreateDate = "";
    if (!this.filter.endDate) this.filter.endDate = "";
    if (resetPage) this.page = 1;
    this.apiService.getPaged(this.filter, this.page).subscribe(
      (response) => {
        this.solicitudes = response.data;
        this.dataPage = response;
        this.loading.hide();

      },
      (error) => {
        this.alert.error(error.error);
        this.loading.hide();
      }
    );


  }

  changePage(next: boolean) {
    this.page = next ? (this.page += 1) : (this.page -= 1);
    if (this.page < 0) this.page = 0;
    this.getAll(false);
  }


  editOrAddCompany(id: number) {

    var modal = this.modalService.open(SolicitudAddComponent, config.modalConfig);
    modal.componentInstance.id = id;
    modal.componentInstance.notifyParent.subscribe((result) => {
      if (id != null) {
        this.getAll(true);
      }
      else {
        this.getAll(false);
      }
    });
  }
}
